#!/bin/bash

java -Djava.library.path=lib -cp CapioWebSocket.jar:lib/json-20090211.jar:lib/okhttp-2.4.0.jar:lib/okhttp-ws-2.4.0.jar:lib/okio-1.4.0.jar:lib/engine.io-client-0.5.1.jar:lib/socket.io-client-0.5.1.jar:lib/commons-cli-1.3.jar:lib/jspeex.jar:lib/libjitsi.jar: com.capio.clients.CapioTestClient -e http://api.capio.ai -w $1 -s true -n true -a false -r true -k core -c opus
