#!/bin/bash

java -cp CapioWebSocket.jar:json-20090211.jar:okhttp-2.4.0.jar:okhttp-ws-2.4.0.jar:okio-1.4.0.jar:engine.io-client-0.5.1.jar:socket.io-client-0.5.1.jar:commons-cli-1.3.jar com.capio.clients.CapioTestClient -e http://api.capio.ai -w $1 -s true -k core -n true -a false
